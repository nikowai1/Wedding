﻿namespace Wedding.Services.Data
{
    using System.Collections.Generic;
    using System.Linq;

    using Wedding.Data.Common.Repositories;
    using Wedding.Data.Models;

    public class GuestsService : IGuestsService
    {
        private readonly IDeletableEntityRepository<Guest> guestsRepository;

        public GuestsService(IDeletableEntityRepository<Guest> guestsRepository)
        {
            this.guestsRepository = guestsRepository;
        }

        public IEnumerable<KeyValuePair<string, string>> GetAllGuestsAsValuePairs()
        {
            return this.guestsRepository.AllAsNoTracking()
                .Select(x => new
                {
                    x.Id,
                    x.Name,
                }).ToList().Select(x => new KeyValuePair<string, string>(x.Id.ToString(), x.Name));
        }
    }
}
