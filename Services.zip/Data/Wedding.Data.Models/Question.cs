﻿namespace Wedding.Data.Models
{
    using System.Collections.Generic;

    using Wedding.Data.Common.Models;

    public class Question : BaseDeletableModel<int>
    {
        public Question()
        {
            this.Names = new HashSet<Guest>();
        }

        public string Name { get; set; }

        public virtual ICollection<Guest> Names { get; set; }
    }
}
