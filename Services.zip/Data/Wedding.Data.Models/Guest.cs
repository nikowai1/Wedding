﻿namespace Wedding.Data.Models
{
    using Wedding.Data.Common.Models;

    public class Guest : BaseDeletableModel<int>
    {
        public string Name { get; set; }

        public int QuestionId { get; set; }

        public Question Question { get; set; }
    }
}
