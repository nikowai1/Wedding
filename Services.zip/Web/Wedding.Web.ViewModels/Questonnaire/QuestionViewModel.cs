﻿namespace Wedding.Web.ViewModels.Questonnaire
{
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;

    public class QuestionViewModel
    {
        public string Name { get; set; }

        [Display(Name = "Въведете вашето име")]
        public int GuestId { get; set; }

        public IEnumerable<KeyValuePair<string, string>> Answers { get; set; }
    }
}
