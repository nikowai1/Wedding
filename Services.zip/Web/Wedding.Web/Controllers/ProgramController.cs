﻿namespace Wedding.Web.Controllers
{
    using Microsoft.AspNetCore.Mvc;

    public class ProgramController : Controller
    {
        public IActionResult Index()
        {
            return this.View();
        }
    }
}
