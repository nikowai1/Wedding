﻿namespace Wedding.Web.Controllers
{
    using System.Diagnostics;
    using System.Net;

    using Microsoft.AspNetCore.Mvc;
    using Newtonsoft.Json;
    using Wedding.Web.ViewModels;

    public class HomeController : BaseController
    {
        public IActionResult Index()
        {
            var webClient = new WebClient();
            var json = System.IO.File.ReadAllText(@"wwwroot\animationJson\DJI_0446-1.json");
            var animation = JsonConvert.DeserializeObject<object>(json);
            return this.View();
        }

        public IActionResult Privacy()
        {
            return this.View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return this.View(
                new ErrorViewModel { RequestId = Activity.Current?.Id ?? this.HttpContext.TraceIdentifier });
        }
    }
}
