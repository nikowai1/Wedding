﻿namespace Wedding.Web.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using System.Threading.Tasks;
    using Wedding.Services.Data;
    using Wedding.Web.ViewModels.Questonnaire;

    public class QuestionnaireController : Controller
    {
        private readonly IGuestsService guestsService;

        public QuestionnaireController(IGuestsService guestsService)
        {
            this.guestsService = guestsService;
        }

        public IActionResult Question()
        {
            var viewModel = new QuestionViewModel();
            viewModel.Answers = this.guestsService.GetAllGuestsAsValuePairs();
            return this.View(viewModel);
        }

        [HttpPost]
        public IActionResult Question(QuestionViewModel input)
        {
            return this.Redirect("/");
        }
    }
}
