﻿namespace Wedding.Common
{
    public static class GlobalConstants
    {
        public const string SystemName = "Wedding";

        public const string AdministratorRoleName = "Administrator";
    }
}
